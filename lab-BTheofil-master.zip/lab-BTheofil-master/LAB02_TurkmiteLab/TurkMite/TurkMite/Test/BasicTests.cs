using System;
using TurkMite;
using Microsoft.VisualStudio.TestPlatform;

namespace Test
{
    public class BasicTests
    {
        []
        public void Test1()
        {
            var t = new TurkMite.TurkMite();
            var ret = t.Step(t.white);
            Assert.Equal(-1, ret.deltaDirection);
            Assert.Equal(t.black, ret.newColor);
        }
    }
}
