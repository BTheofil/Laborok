﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TurkMiteUnitTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            var t = new TurkMite.TurkMite();
            var ret = t.Step(t.white);
            Assert.AreEqual(-1, ret.deltaDirection);
            Assert.AreEqual(t.black, ret.newColor);
        }
    }
}
