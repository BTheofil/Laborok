﻿namespace Numbers
{
    public class SumPrimeNumbers : SolutionProviderBase
    {
        private int upperlimit;

        public SumPrimeNumbers(int upperlimit)
        {
            this.upperlimit = upperlimit;
        }

        public override int CalculateSolution()
        {
            int sum = 0;
            for (int i = 2; i < upperlimit; i++)
            {
                if (IsPrime(i))
                {
                    sum += i;
                }
            }
            return sum;
        }

        private bool IsPrime(int n)
        {
            for (int i = 2; i < n; i++)
            {
                if (n % i == 0)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
