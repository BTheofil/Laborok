﻿using Numbers;
using Xunit;

namespace Tests
{
    public class PrimeTest
    {
        [Fact]
        public void SumPrimeNumbers10()
        {
            var p = new SumPrimeNumbers(10);
            Assert.Equal(17, p.CalculateSolution());
        }
    }
}
