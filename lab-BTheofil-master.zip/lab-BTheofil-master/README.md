# EViP - Eseményvezérelt és Vizuális Programozás (VIAUBB01)

Erről a repositoryról készülnek a hallgatói személyes másolatok a classroom.github.com segítségével.
A repository private, a tárgy oktatóin kívül más nem láthatja.
Az egyértelmű azonosíthatóság érdekében kérünk, add meg az alábbiakat:

## NÉV: Bodnár Theofil
## Neptun-kód: xabhev
## Kurzus: L05

# Hasznos linkek 

- [Youtube csatorna](https://www.youtube.com/playlist?list=PLb8EWPCoqCDYUeE-MoAb_VJvKO6dRXkow)
- [Az eredeti kiindulási repository: https://github.com/eviplabs/start/](https://github.com/eviplabs/start/)
