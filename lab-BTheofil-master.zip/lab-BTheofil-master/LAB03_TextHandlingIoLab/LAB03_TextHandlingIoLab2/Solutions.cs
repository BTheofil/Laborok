﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace LAB03_TextHandlingIoLab2
{
    class Solutions
    {
        private const string Regex = @"^(?(";
        #region Examples and helper
        internal bool MatchingExample()
        {
            var regex = new Regex(@"<.+>");
            Match m = regex.Match(@"<valami>");
            return m.Success;   // returns true
        }

        internal string[] CollectingMatchesExample()
        {
            // Returns "valami", "még valami" (anything except ">" between "<" and ">".
            return Collect(@"<valami> és <még valami>", @"<[^>]+>").ToArray();
        }

        private IEnumerable<string> Collect(string text, string regex)
        {
            var re = new Regex(regex);
            var matches = re.Matches(text);
            foreach (Match match in matches)
                yield return match.Captures[0].Value;
        }
        #endregion

        #region Email
        internal bool IsEmailAddress(string v)
        {
            var regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,7})+)$");
            Match m = regex.Match(v);
            return m.Success;   // returns true

            
        }

        internal string[] CollectEmailAddresses(string s)
        {
            return Collect(s,@"[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?").ToArray();
        }
        #endregion

        #region Phone numbers
        internal bool IsPhoneNumber(string v)
        {
            var regex = new Regex(@"^[\+?|06]\d{1,2}-?\d{2,3}-?\d{3}-?\d{3,4}$");
            Match m = regex.Match(v);
            return m.Success;   // returns true
        }

        internal string[] CollectPhoneNumbers(string text)
        {
            return Collect(text, @"[\+?|\d{1}]-?\d{1,2}-?\d{3}-?\d{3}-?\d{3,4}").ToArray();
        }

        internal bool IsHungarianMobilePhoneNumber(string v)
        {
            var regex = new Regex(@"^[\+?]\d{2}?\d{2}-?\d{3}-?\d{4}$");
            Match m = regex.Match(v);
            return m.Success;   // returns true
        }
        #endregion

        #region MusicBox
        internal bool IsInsideMusicBox(string text)
        {
            var regex = new Regex(@"<.+>");
            Match m = regex.Match(text);
            return m.Success;   // returns true
        }

        internal string[] CollectWhatsInsideMusicBox(string text)
        {
            throw new NotImplementedException();
        }

        internal IEnumerable<char> HightlightNotesInMusicBox(string text)
        {
            throw new NotImplementedException();
        }
        #endregion

        #region PlusCode
        internal bool IsPlusCode(string text)
        {
            throw new NotImplementedException();
        }

        internal bool IsPlusCodeInBudapest(string text)
        {
            throw new NotImplementedException();
        }

        internal string[] CollectFullPlusCodes(string text)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Date
        internal string[] CollectDates(string text)
        {
            throw new NotImplementedException();
        }

        private IEnumerable<string> EnumerateDates(string text)
        {
            throw new NotImplementedException();
        }

        #endregion

    }
}
