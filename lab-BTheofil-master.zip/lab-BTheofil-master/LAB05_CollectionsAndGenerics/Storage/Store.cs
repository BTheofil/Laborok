﻿using System;
using System.Collections.Generic;

namespace Storage
{
    public class Store<T> where T : IStorable
    {
        private Dictionary<string, IStorable> storage = new Dictionary<string, IStorable>();

        public int Count()
        {
            return storage.Count;
        }

        public void Insert(IStorable item)
        {
            if (!storage.ContainsKey(item.Id) && item.InStock > 1) {
                storage.Add(item.Id,item);
            }
        }

        public void InsertMany(List<IStorable> items)
        {
            foreach (var item in items)
            {
                Insert(item);
            }
        }

        public IStorable GetById(string id)
        {
            return storage[id];
        }

        public Dictionary<string, IStorable> GetAllDictionary()
        {
            return storage;
        }

        public List<IStorable> GetAllList()
        {
            throw new NotImplementedException();
        }

        public void Sell(string id, int amount)
        {
            
        }

        public void Buy(IStorable item)
        {
            throw new NotImplementedException();
        }

        public void Buy(string id, int amount)
        {
            throw new NotImplementedException();
        }

        public void Remove(string id)
        {
            throw new NotImplementedException();
        }

        public void Remove(IStorable item)
        {
            throw new NotImplementedException();
        }
    }
}
