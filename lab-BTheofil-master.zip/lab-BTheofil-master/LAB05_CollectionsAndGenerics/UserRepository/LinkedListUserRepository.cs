﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UserRepository
{
    public class LinkedListUserRepository : IUserRepository
    {
        LinkedList<User> users = new LinkedList<User>();

        public int Count()
        {
            return users.Count;
        }

        public User Get(int index)
        {
            return users.ElementAt(index);
        }

        public User GetById(string id)
        {
            // Binaris kereses rendezett tombon
            var left = 0;
            var right = users.Count - 1;
            while (left <= right)
            {
                var mid = (left + right) / 2;
                if (string.Compare(this.Get(mid).Id, id) > 0)
                {
                    right = mid - 1;
                }
                else if (string.Compare(this.Get(mid).Id, id) < 0)
                {
                    left = mid + 1;
                }
                else
                {
                    return users.ElementAt(mid);
                }
            }
            return null;
        }

        public void Insert(User user)
        {
            if (users.Count < 1)
            {
                users.AddLast(user);
            }
            else {

                for (var recentNode = users.First; recentNode != null; recentNode = recentNode.Next)

                    if (recentNode.Next != null && string.Compare(user.Id, recentNode.Value.Id) > 0 && string.Compare(user.Id, recentNode.Next.Value.Id) < 0)
                    {
                        users.AddAfter(recentNode, user);
                        return;
                    }
                users.AddLast(user);
            }


        }
    }
}
