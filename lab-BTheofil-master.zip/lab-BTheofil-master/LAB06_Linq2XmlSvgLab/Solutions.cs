﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace Linq2XmlSvgLab
{
    public class Solutions
    {
        private readonly XElement root;
        private readonly XNamespace ns = "http://www.w3.org/2000/svg";

        public Solutions(string svgFileName)
        {
            root = XElement.Load(svgFileName);
        }

        private IEnumerable<XElement> Rects => root.Descendants(ns + "rect");
        private IEnumerable<XElement> Texts => root.Descendants(ns + "text");

        #region A laborfeladatok megoldásai
        // Minden téglalap (rect elem) felsorolása
        internal IEnumerable<XElement> GetAllRectangles()
        {
            return Rects;
        }

        // Hány olyan szöveg van, aminek ez a tartalma?
        internal int CountTextsWithValue(string v)
        {
            IEnumerable<XElement> textex = Texts.Where(t => t.Value.Contains(v));
            return textex.Count();
        }

        #region Téglalap szűrések
        // Minden olyan rect elem felsorolása, aminek a kerete adott vastagságú.
        //  A keretvastagság (más beállításokkal együtt) a "style" szöveges attribútumban
        //  szerepel, pl. "stroke-width:2".
        internal IEnumerable<XElement> GetRectanglesWithStrokeWidth(int width)
        {
            return Rects.Where(r => r.Attribute("style").Value.Contains($"stroke-width:{width}"));
        }

        // Adott x koordinátájú téglalapok színének visszaadása szövegesen (pl. piros esetén "#ff0000").
        internal IEnumerable<string> GetColorOfRectanglesWithGivenX(double x)
        {             
            return Rects.Where(r => r.GetDoubleAttribute("x").Equals(x)).Select(r => r.GetFillColor());
        }

        // Az adott ID-jú téglalap pozíciójának (x,y) visszaadása.
        internal Tuple<double , double > GetRectangleLocationById(string id)
        {
            double d1 = Rects.Where(r => r.GetId().Equals(id)).Select(r => r.GetX()).First();
            double d2 = Rects.Where(r => r.GetId().Equals(id)).Select(r => r.GetY()).First();
            return new Tuple<double, double>(d1, d2);
        }

        // A legnagyobb y értékkel rendezkező téglalap ID-jának visszaadása.
        internal string GetIdOfRectangeWithLargestY()
        {
            var maxY = Rects.Select(r => r.GetY()).Max();
            var sel = Rects.Where(r => r.GetDoubleAttribute("y") == maxY).First();
            return sel.GetId();
        }

        // Minden olyan téglalap ID-jának felsorolása, ami legalább kétszer olyan magas mint széles.
        internal IEnumerable<string> GetRectanglesAtLeastTwiceAsHighAsWide()
        {
            var tegla = Rects.Where(r => r.GetWidth() * 2 < r.GetHeight());
            return tegla.Select(r => r.GetId());
        }
        #endregion

        #region Group kezelés
        // Adott ID-jú group-ban lévő téglalapok színét sorolja fel.
        internal IEnumerable<string> GetColorsOfRectsInGroup(string id)
        {
            var tegla = Rects.Where(r => r.Parent.Attribute("id").Value.Equals(id));
            return tegla.Select(r => r.GetFillColor());
        }
        #endregion

        #region Téglalapok és szövegek viszonya
        // Minden olyan rect elem felsorolása, amiben van bármilyen szöveg.
        //  (Olyan rect, aminek a területén van egy szövegnek a kezdőpontja (x,y).)
        internal IEnumerable<XElement> GetRectanglesWithTextInside()
        {
            return Rects.Where(r => Texts.Any(t => r.GetX() <= t.GetX() && r.GetY() <= t.GetY() && (r.GetX() + r.GetWidth()) >= t.GetX() 
            && (r.GetY() + r.GetHeight()) >= t.GetY()));
        }

        // Adott színű téglalapon belüli szöveg visszaadása.
        //  Feltételezhetjük, hogy csak egyetlen ilyen színű téglalap van és abban egyetlen
        //  szöveg szerepel.
        internal string GetSingleTextInSingleRectangleWithColor(string color)
        {
            return Texts.Where(t => Rects.Any(r => r.GetFillColor() == color && (r.GetX() <= t.GetX() && r.GetY() <= t.GetY()
            && (r.GetX() + r.GetWidth()) >= t.GetX() && (r.GetY() + r.GetHeight()) >= t.GetY()))).FirstOrDefault()?.Value;
        }

        // Minden téglalapon kívüli szöveg felsorolása.
        internal IEnumerable<string> GetTextsOutsideRectangles()
        {
            return Texts.Where(t => !Rects.Any(r => r.GetX() <= t.GetX() && r.GetY() <= t.GetY() && (r.GetX() + r.GetWidth()) >= t.GetX() 
            && (r.GetY() + r.GetHeight()) >= t.GetY())).Select(t => t.Value);
        }
        #endregion

        #region Téglalapok egymáshoz képesti viszonya
        // Az egyetlen olyan téglalap pár visszaadása (id attribútumuk értékével), amik legfeljebb
        //  adott távolságra vannak egymástól.
        // (Itt nem gond, ha foreach-et használsz, de jobb, ha nem.)
        internal Tuple<string , string> GetSingleRectanglePairCloseToEachOther(double maxDistance)
        {
            return new Tuple<string, string>(null, null);
        }
        #endregion

        #region ILookup és Aggregate használata
        // Egy ILookup visszaadása, mely minden szöveghez megadja az ilyen szöveget tartalmazó
        //  téglalapok színét. (Az ILookup-ban csak azok a szövegek szerepelnek kulcsként, amikhez van
        //  is téglalap.)
        internal ILookup<string, string> GetBoundingRectangleColorListForEveryText()
        {
            return null;
        }

        // Minden téglalapon belüli szöveg ABC sorrendben egymás mögé fűzése, ", "-zel elválasztva.
        //  (Az "OrderBy(s=>s)" rendezése most elegendő lesz.)
        // Használd az Aggregate Linq metódust egy StringBuilderrel az összegyűjtéshez!
        internal string ConcatenateOrderedTextsInsideRectangles()
        {
            return Texts.Where(t => Rects.Any(r => r.GetX() <= t.GetX() && r.GetY() <= t.GetY() && (r.GetX() + r.GetWidth()) >= t.GetX() &&
            (r.GetY() + r.GetHeight()) >= t.GetY())).Select(t => t.Value).OrderBy(x => x).Aggregate("", (current, following) => current + ", " + following).Remove(0, 2);
        }

        // Az adott kontúrszélességű (stroke width) téglalapok által együttesen lefedett terület
        //  szélességét és magasságát adja meg
        internal Tuple<double, double> GetEffectiveWidthAndHeight(int strokeThickness)
        {
            return new Tuple<double, double>(0, 0);

        }
        #endregion
        #endregion

        #region Segédmetódusok
        // Ezeknek a metódusoknak az implementálása nem kötelező, csak ajánlás.
        //  Ezekre a funkciókra lehet, hogy többször is szükséged lesz a feladatok
        //  megoldása során, így érdemes őket kiszervezni külön metódusokba.
        class Boundary
        {
            public double Left = double.MaxValue;
            public double Top = double.MaxValue;
            public double Right = double.MinValue;
            public double Bottom = double.MinValue;

            public double Width => Right - Left + 1;
            public double Height => Bottom - Top + 1;

            public void UpdateToCoverRect(XElement rect)
            {
                Left = Math.Min(Left, rect.GetX());
                Right = Math.Max(Right, rect.GetX() + rect.GetWidth() - 1);
                Top = Math.Min(Top, rect.GetY());
                Bottom = Math.Max(Bottom, rect.GetY() + rect.GetHeight() - 1);
            }
        }

        // A kapott rect magassága legalább kétszer akkora, mint a szélessége?
        private bool IsAtLeastTwiceAsHighAsWide(XElement rect)
        {
            return false;
        }

        // A this.Rects attribútumból felsorolja azokat az elemeket, melyek kitöltési színe a megadott szín.
        private IEnumerable<XElement> GetRectanglesWithColor(string color)
        {
            return null;
        }

        // Igaz, ha a megadott pont a rect-en belül van.
        //  Használhatod a lentebb megírandó GetRectBoundaries-t.
        private bool IsInside(XElement rect, Tuple<double , double > p)
        {
            double width = rect.GetX() + rect.GetWidth();
            double heigth = rect.GetY() + rect.GetHeight();
            if ((rect.GetX() < p.Item1 &&  p.Item1 > width) && (rect.GetY() > p.Item2 && p.Item2 > heigth)) {

                return true;
            }
            return false;
        }

        // Igaz, ha a két téglalap (r1 és r2) között a távolság egyik tengely
        //  mentén sem nagyobb, mint maxDistance.
        private bool AreClose(XElement r1, XElement r2, double maxDistance)
        {
            return false;
        }

        // Visszaadja egy téglalap határait. Figyelem! Ha left==2 és width==3,
        //  akkor right==4 és nem 5! Hasonlóan a magasságra is.
        private Tuple<double ,double ,double ,double > GetRectBoundaries(XElement r)
        {
            return new Tuple<double, double, double, double>(0,0,0,0);
        }
        #endregion
    }
}
