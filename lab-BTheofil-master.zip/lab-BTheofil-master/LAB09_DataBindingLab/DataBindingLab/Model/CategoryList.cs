﻿using System.Collections.ObjectModel;

namespace DataBindingLab.Model
{
    public class CategoryList : ObservableCollection<Category>
    {
    }
}
