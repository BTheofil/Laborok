﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HaziFeladatAruhaz
{
    class Discount
    {
        private int a;

        public Discount() {
            this.a = a;
        }

    }
}
