﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HaziFeladatAruhaz
{
    class Shop
    {

        private Dictionary<string, int> raktar;
        private Dictionary<string, List<int>> akciok;
        private Dictionary<char, int> termekekEsDarabjai;

        public Shop()
        {
            this.raktar = new Dictionary<string, int>();
            this.akciok = new Dictionary<string, List<int>>();
            this.termekekEsDarabjai = new Dictionary<char, int>();
        }

        public int raktarCount() {
            return raktar.Count();
        }

        public void RegisterProduct(string nev, int ar) {

            raktar.Add(nev,ar);

        }

        public int GetPrice(string nev) {

            char[] box = nev.ToCharArray();
            int osszeg = 0;

            for (int i=0; i<box.Length; i++) {

                char temp = box[i];
                string aktualis;
                aktualis = temp.ToString();

                foreach (KeyValuePair<string, int> kvp in raktar)
                {
                    if (kvp.Key == aktualis) {
                        osszeg += kvp.Value;
                    }
                }
            }
            
            return osszeg;
        }

        public int szovegFeldolgozo(string termekek) {

            //vissza kene adni, hogy milyen karakterek voltak es hany darab volt belole
            char[] box = termekek.ToCharArray();
            int index = box.Length-1;
            int szamlalo = 0;

            for (int i = 0; i < box.Length-1; i++)
            {          
                //ha azonos akkor elkezdjuk szamolni hanyszor azonos
                if (box[i].Equals(box[i + 1]))                
                {                
                    szamlalo++;                    
                }

                //ha mar mas kovetkezik akkor felirasra kerul
                if(box[i] != box[i+1]) {
                    termekekEsDarabjai.Add(box[i], szamlalo);                   
                }

                if (box.Length-2 == i && box[i] == box[i+1]) {
                    termekekEsDarabjai.Add(box[i], 1);
                }

            }
            return termekekEsDarabjai.Count;

            foreach (char betu in box)
            {
                if (betu == box[index])
                {
                    szamlalo++;
                }
                else {
                    termekekEsDarabjai.Add(betu,szamlalo);
                }
            }
            return termekekEsDarabjai.Count;

            int xd = 0;
            foreach (KeyValuePair<char, int> item in termekekEsDarabjai)
            {
                xd = item.Value;
            }

            return xd;
        }

        public void RegisterCountDiscount(string nev, int minDB, int ajandek) {

            List<int> ertek = new List<int>();

            ertek.Add(minDB);
            ertek.Add(ajandek);

            akciok.Add(nev, ertek);

        }

    }
}
