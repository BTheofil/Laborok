﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace HaziFeladatAruhaz
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void RegisterProduct()
        {
            Shop test = new Shop();

            test.RegisterProduct("A", 10);
            test.RegisterProduct("C", 20);
            test.RegisterProduct("E", 50);
            var price = test.GetPrice("ACEE");  // 130-at ad vissza

            Assert.AreEqual(130, price);

        }

        public void harmatFizetNegyetVihet() {

            Shop test = new Shop();

            test.RegisterProduct("A", 10);
            test.RegisterProduct("E", 50);
            test.RegisterCountDiscount("A", 3, 4); // 3 áráért 4-et vihet
            var price = test.GetPrice("AAAAAEEE");  // 5*10+3*50 helyett 4*10+3*50

            Assert.AreEqual(190, price);

        }
    }
}
